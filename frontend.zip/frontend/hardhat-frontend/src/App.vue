<script setup>

</script>

<template>
 <router-view/>
</template>

<style>
#app{
  margin: 0;
  padding: 0;
  border: none;
  font-size: 100%;
  font: inherit;
  vertical-align: baseline;
}
body {
  margin: 0;
  padding: 0;
  font-size: 100%;
  font-family: inherit;
  line-height: inherit;
  color: inherit;
  background-color: transparent;
}
</style>
